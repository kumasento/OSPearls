#include <stdio.h>
#include <stdlib.h>

#include "libthread.h"


int main() {
    initEnv();

    return 0;
}

